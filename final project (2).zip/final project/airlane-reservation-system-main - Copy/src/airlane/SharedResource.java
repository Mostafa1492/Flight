    package airlane;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;    

public class SharedResource{

	private final HashMap<Integer,String> places;

	
	SharedResource()
	{
		this.places = new HashMap<>();
		for(int i=1;i<=25;i++) this.places.put(i,"0");

	}
	
	public HashMap<Integer, String> Getplaces() {
		return this.places;
	}
	public int placeCount() {
		return this.places.size();
	}

}

    
